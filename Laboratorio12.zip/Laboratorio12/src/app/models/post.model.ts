export interface Post {
    title: string;
    details: string;
}