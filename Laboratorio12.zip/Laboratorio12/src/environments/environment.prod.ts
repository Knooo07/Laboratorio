export const environment = {
  production: true,
  firebaseConfig:{
    apiKey: "AIzaSyB20vrzcY2m83RNhaz-Su6fTjFLVh57WZg",
    authDomain: "lab12-9b7c2.firebaseapp.com",
    projectId: "lab12-9b7c2",
    storageBucket: "lab12-9b7c2.firebasestorage.app",
    messagingSenderId: "471415688804",
    appId: "1:471415688804:web:a76f147af84b2f58359971",
    measurementId: "G-9XKR43ZKRD"
  }
};
