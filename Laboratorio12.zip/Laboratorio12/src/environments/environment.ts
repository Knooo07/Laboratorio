// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig:{
    apiKey: "AIzaSyB20vrzcY2m83RNhaz-Su6fTjFLVh57WZg",
    authDomain: "lab12-9b7c2.firebaseapp.com",
    projectId: "lab12-9b7c2",
    storageBucket: "lab12-9b7c2.firebasestorage.app",
    messagingSenderId: "471415688804",
    appId: "1:471415688804:web:a76f147af84b2f58359971",
    measurementId: "G-9XKR43ZKRD"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
